import { UseGuards } from '@nestjs/common';
import { Args, Mutation, Resolver } from '@nestjs/graphql';
import { GqlAuthAccessGuard } from 'src/commons/auth/gql-auth-guard';
import { CurrentUser, ICurrentUser } from 'src/commons/auth/gql-user.param';
import { iamportService } from '../iamport/iamport.service';
import { RentReservation } from './entities/rentReservation.entity';
import { RentReservationService } from './rentReservation.service';

@Resolver()
export class RentReservationResolver {
  constructor(
    private readonly rentReservationService: RentReservationService, //
  ) {}

  @UseGuards(GqlAuthAccessGuard)
  @Mutation(() => RentReservation)
  createRentReservation(
    @Args('imp_uid') imp_uid: string,
    @Args('price') price: number,
    @Args('rentId') rentId: string,
    @CurrentUser() currentUser: ICurrentUser,
  ) {
    //
    return this.rentReservationService.create({
      imp_uid,
      price,
      currentUser,
      rentId,
    });
  }
}
