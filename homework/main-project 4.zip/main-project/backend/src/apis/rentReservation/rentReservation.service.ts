import {
  ConflictException,
  Injectable,
  UnprocessableEntityException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import {
  POINT_TRANSACTION_STATUS_ENUM,
  RentReservation,
} from './entities/rentReservation.entity';
import { RentUser } from '../rentUser/entities/rentUser.entity';
import { iamportService } from '../iamport/iamport.service';

@Injectable()
export class RentReservationService {
  constructor(
    @InjectRepository(RentReservation)
    private readonly rentReservationRepository: Repository<RentReservation>,

    @InjectRepository(RentUser)
    private readonly rentUserRepository: Repository<RentUser>,

    private readonly iamportService: iamportService,
  ) {}

  async findAll() {
    return await this.rentReservationRepository.find({
      relations: ['rentUser', 'rent'],
    });
  }

  async findOne({ impUid }) {
    return await this.rentReservationRepository.findOne({
      where: { impUid },
      relations: ['rentUser', 'rent'],
    });
  }

  async create({ imp_uid, price, currentUser, rentId }) {
    const access_token = await this.iamportService.getToken();
    const payment = await this.iamportService.getPaymentData({
      imp_uid,
      access_token,
    });

    // 유효하지 않은 아이디인 경우
    if (!payment.imp_uid)
      throw new UnprocessableEntityException('유효하지 않은 아이디입니다');

    // 이미 구매한 숙소인 경우
    if (rentId === payment.merchant_uid)
      throw new UnprocessableEntityException('이미 예약한 숙소입니다.');

    // 이미 등록된 아이디인 경우
    if (imp_uid === payment.imp_uid)
      throw new ConflictException('이미 등록된 아이디입니다.');

    // 1. RentReservation 테이블에 거래기록 1줄 생성

    const ids1 = await this.rentUserRepository.findOne({
      where: { email: currentUser.email }, // currnetUser에 로그인한 유저의 모든 정보가 담긴다.
    });

    // 2. 검증 후 DB에 저장하기
    const rentReservation = await this.rentReservationRepository.save({
      imp_uid: imp_uid,
      price: price,
      user: currentUser,
      rent: { id: rentId },
      rentUser: { id: ids1.id },
      status: POINT_TRANSACTION_STATUS_ENUM.PAYMENT, // 지불한 상태를 저장!
    });

    // 3. 최종결과 프론트엔드에 돌려주기
    return rentReservation;
  }
}
