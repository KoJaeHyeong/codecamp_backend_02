import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import axios from 'axios';
import { assertCompositeType } from 'graphql';
import { Repository } from 'typeorm';
import { RentReservation } from '../rentReservation/entities/rentReservation.entity';

@Injectable()
export class iamportService {
  constructor(
    @InjectRepository(RentReservation)
    private readonly rentResrvationRepository: Repository<RentReservation>,
  ) {}

  // 액세스 토큰(access token) 발급 받기
  async getToken() {
    const token = await axios({
      url: 'https://api.iamport.kr/users/getToken',
      method: 'post', // POST method
      headers: { 'Content-Type': 'application/json' }, // "Content-Type": "application/json"
      data: {
        imp_key: '0991982179956392', // REST API 키
        imp_secret:
          'e900b5c7d6187e23ba9f44f4b533e0a0566416eb92329cc0fcb1a84b76161164701debec0ef4a4d5', // REST API Secret
      },
    });

    const { access_token } = token.data.response; // 인증 토큰
    console.log(access_token, 'AAA');
    return access_token;
  }

  // imp_uid로 아임포트 서버에서 결제 정보 조회
  async getPaymentData({ imp_uid, access_token }) {
    const paymentData = await axios({
      url: `https://api.iamport.kr/payments/${imp_uid}`, // imp_uid 전달
      method: 'get', // GET method
      headers: { Authorization: access_token }, // 인증 토큰 Authorization header에 추가
    });
    const payment = paymentData.data.response; // 조회한 결제 정보
    console.log(payment, 'BBBBBBBB');

    return payment; //
  }
}
