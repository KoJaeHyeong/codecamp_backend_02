import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import {
  POINT_TRANSACTION_STATUS_ENUM,
  RentReservation,
} from './entities/rentReservation.entity';
import { RentUser } from '../rentUser/entities/rentUser.entity';

@Injectable()
export class RentReservationService {
  constructor(
    @InjectRepository(RentReservation)
    private readonly rentReservationRepository: Repository<RentReservation>,

    @InjectRepository(RentUser)
    private readonly rentUserRepository: Repository<RentUser>,
  ) {}

  async findAll() {
    return await this.rentReservationRepository.find({
      relations: ['rentUser', 'rent'],
    });
  }

  async findOne({ impUid }) {
    return await this.rentReservationRepository.findOne({
      where: { impUid },
      relations: ['rentUser', 'rent'],
    });
  }

  async create({ impUid, price, currentUser }) {
    // 1. RentReservation 테이블에 거래기록 1줄 생성
    const rentReservation = await this.rentReservationRepository.save({
      impUid: impUid,
      price: price,
      user: currentUser,
      // rent: { id: rentId },
      // rentUser: { id: rentUserId },
      status: POINT_TRANSACTION_STATUS_ENUM.PAYMENT, // 지불한 상태를 저장!
    });

    // 2. 유저의 돈 찾아오기
    await this.rentUserRepository.findOne({ id: currentUser.id });

    // 3. 유저의 돈 업데이트
    // await this.rentUserRepository.update(
    //   { id: user.id },
    //   { price: user.price }, // 할인해주는 로직 만들기!!
    // );
    // 4. 최종결과 프론트엔드에 돌려주기
    return rentReservation;
  }
}
