import { InputType, OmitType } from '@nestjs/graphql';
import { RentImage } from '../entities/rentImage.entity';

@InputType()
export class RentImageInput extends OmitType(
  RentImage, //
  ['id'],
  InputType,
) {}
