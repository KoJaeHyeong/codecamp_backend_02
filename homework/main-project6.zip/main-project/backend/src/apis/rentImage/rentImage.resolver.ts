import { Args, Mutation, Resolver, Query } from '@nestjs/graphql';
import { RentImage } from './entities/rentImage.entity';
import { RentImageInput } from './dto/rentImage.input';
import { RentImageService } from './rentImage.service';
import { updateRentImageInput } from './dto/updateRentImage.input';

@Resolver()
export class RentImageResolver {
  constructor(
    private readonly rentImageService: RentImageService, //
  ) {}

  @Mutation(() => RentImage)
  createImage(
    @Args('rentImageInput') rentImageInput: RentImageInput, //
  ) {
    return this.rentImageService.create({ rentImageInput });
  }

  @Mutation(() => RentImage)
  updateImage(
    @Args('updateRentImageInput') updateRentImageInput: updateRentImageInput,
  ) {
    return this.rentImageService.update({ updateRentImageInput });
  }
}
