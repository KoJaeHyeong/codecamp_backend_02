export const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: '코드캠프 백엔드',
      version: '1.0.0',
    },
  },
  apis: ['./swagger/*.js'],
};